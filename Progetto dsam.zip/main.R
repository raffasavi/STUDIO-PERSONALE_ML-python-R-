install.packages("ggplot2")
install.packages("reshape2")
install.packages("caret")
install.packages("mlbench")
install.packages("class")
install.packages("neuralnet")
install.packages("rpart")
install.packages("rpart.plot")

library(ggplot2)
library(reshape2)
library(caret)
library(mlbench)
library(class)
library(neuralnet)
library(rpart)
library(rpart.plot)

#dataset
ds <- read.csv("diabetes_data_upload.csv", header = T)
head(ds)
table(ds$class)
barplot(table(ds$class),col="#3366cc")
ds$Gender = as.integer(factor(ds$Gender, levels = c('Female','Male'), labels = c(0,1)))
ds$Polyuria = as.integer(factor(ds$Polyuria, levels = c('No','Yes'), labels = c(0,1)))
ds$Polydipsia = as.integer(factor(ds$Polydipsia, levels = c('No','Yes'), labels = c(0,1)))
ds$sudden.weight.loss = as.integer(factor(ds$sudden.weight.loss, levels = c('No','Yes'), labels = c(0,1)))
ds$weakness = as.integer(factor(ds$weakness, levels = c('No','Yes'), labels = c(0,1)))
ds$Polyphagia = as.integer(factor(ds$Polyphagia, levels = c('No','Yes'), labels = c(0,1)))
ds$Genital.thrush = as.integer(factor(ds$Genital.thrush, levels = c('No','Yes'), labels = c(0,1)))
ds$visual.blurring = as.integer(factor(ds$visual.blurring, levels = c('No','Yes'), labels = c(0,1)))
ds$Itching = as.integer(factor(ds$Itching, levels = c('No','Yes'), labels = c(0,1)))
ds$Irritability = as.integer(factor(ds$Irritability, levels = c('No','Yes'), labels = c(0,1)))
ds$delayed.healing = as.integer(factor(ds$delayed.healing, levels = c('No','Yes'), labels = c(0,1)))
ds$partial.paresis = as.integer(factor(ds$partial.paresis, levels = c('No','Yes'), labels = c(0,1)))
ds$muscle.stiffness = as.integer(factor(ds$muscle.stiffness, levels = c('No','Yes'), labels = c(0,1)))
ds$Alopecia = as.integer(factor(ds$Alopecia, levels = c('No','Yes'), labels = c(0,1)))
ds$Obesity = as.integer(factor(ds$Obesity, levels = c('No','Yes'), labels = c(0,1)))
ds$class = as.integer(factor(ds$class, levels = c('Negative','Positive'), labels = c(0,1)))
head(ds)
summary(ds)
#normalizzazione
std <- function(x) {
  return((x-min(x))/(max(x)-min(x)))
}
ds$Age <- std(ds$Age)
ds$Gender <- std(ds$Gender)
ds$Polyuria <- std(ds$Polyuria)
ds$Polydipsia <- std(ds$Polydipsia)
ds$sudden.weight.loss <- std(ds$sudden.weight.loss)
ds$weakness <- std(ds$weakness)
ds$Polyphagia <- std(ds$Polyphagia)
ds$Genital.thrush <- std(ds$Genital.thrush)
ds$visual.blurring <- std(ds$visual.blurring)
ds$Itching <- std(ds$Itching)
ds$Irritability <- std(ds$Irritability)
ds$delayed.healing <- std(ds$delayed.healing)
ds$partial.paresis = std(ds$partial.paresis)
ds$muscle.stiffness = std(ds$muscle.stiffness)
ds$Alopecia = std(ds$Alopecia)
ds$Obesity = std(ds$Obesity)
ds$class = std(ds$class)
ds_scaled <- ds
head(ds_scaled)
summary(ds_scaled)
cormat <- cor(ds_scaled[,setdiff(names(ds_scaled),'class')])
ds_melt <- melt(cormat)
ggplot(data = ds_melt, aes(x=Var1, y=Var2, fill = value)) + geom_tile() + scale_fill_gradient2(low='purple',high='red',mid='white',midpoint =0,limit=c(-1,1), name ="Pearson\nCorrelation") + theme(axis.text.x = element_text(angle = 90)) + geom_text(aes(Var2, Var1, label = round(value,2)), color = "black", size = 2)
#k-fold
set.seed(123)
fold <- createFolds(ds$class, k=5)
#Display folds
View(fold)
#train data1
train_data1 <- ds[-fold$Fold1,]
#Test data1
test_data1 <- ds[fold$Fold1,]
#train data2
train_data2 <- ds[-fold$Fold2,]
#Test data2
test_data2 <- ds[fold$Fold2,]
#train data3
train_data3 <- ds[-fold$Fold3,]
#Test data3
test_data3 <- ds[fold$Fold3,]
#train data4
train_data4 <- ds[-fold$Fold4,]
#Test data4
test_data4 <- ds[fold$Fold4,]
#train data5
train_data5 <- ds[-fold$Fold5,]
#Test data5
test_data5 <- ds[fold$Fold5,]

#INIZIO CLASSIFICAZIONE KNN-LO FACCIO UNA VOLTA per diversi k
features_train = train_data1[1:16]
y_train = train_data1[17]
features_test = test_data1[1:16]
y_test = test_data1[17]

k<- numeric()
list_acc <- numeric()
for( i in 1:60){
  kn <- knn(train=features_train,test=features_test,cl=y_train$class,k=i)
  list_acc <- c(list_acc,mean(kn==y_test$class))
  k <- c(k,i)
  }
acc <- data.frame(k = seq(1,60), value = list_acc)
best_k <- subset(acc, value==max(value))[1,]
#andamento accuracy knn
plot(k,list_acc,type="l",main="Accuracy by k")

#migliore e analisi parametri
kn1 <- knn(train=features_train,test=features_test,cl=y_train$class,k=1)
t<-table(kn1,y_test$class)
t
accuracy <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision <- t[2,2]/(t[2,2]+t[2,1])
recall <- t[2,2]/(t[2,2]+t[1,2])
F1 <- 2*(precision*recall)/(precision+recall)

#INIZIO CLASSIFICAZIONE PERCETTRONE
#1
perceptron <- neuralnet(class ~., data=train_data1, hidden=0)
op <- compute(perceptron, test_data1)
prediction<-op$net.result
prediction <- ifelse(prediction > 0.5, 1, 0)
t<-table(test_data1$class,sign(prediction))
acc1 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision1 <- t[2,2]/(t[2,2]+t[2,1])
recall1 <- t[2,2]/(t[2,2]+t[1,2])
F11 <- 2*(precision1*recall1)/(precision1+recall1)
#2
perceptron <- neuralnet(class ~., data=train_data2, hidden=0)
op <- compute(perceptron, test_data2)
prediction<-op$net.result
prediction <- ifelse(prediction > 0.5, 1, 0)
t<-table(test_data2$class,sign(prediction))
acc2 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision2 <- t[2,2]/(t[2,2]+t[2,1])
recall2 <- t[2,2]/(t[2,2]+t[1,2])
F12 <- 2*(precision2*recall2)/(precision2+recall2)
#3
perceptron <- neuralnet(class ~., data=train_data3, hidden=0)
op <- compute(perceptron, test_data3)
prediction<-op$net.result
prediction <- ifelse(prediction > 0.5, 1, 0)
t<-table(test_data3$class,sign(prediction))
acc3 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision3 <- t[2,2]/(t[2,2]+t[2,1])
recall3 <- t[2,2]/(t[2,2]+t[1,2])
F13 <- 2*(precision3*recall3)/(precision3+recall3)
#4
perceptron <- neuralnet(class ~., data=train_data4, hidden=0)
op <- compute(perceptron, test_data4)
prediction<-op$net.result
prediction <- ifelse(prediction > 0.5, 1, 0)
t<-table(test_data4$class,sign(prediction))
acc4 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision4 <- t[2,2]/(t[2,2]+t[2,1])
recall4 <- t[2,2]/(t[2,2]+t[1,2])
F14 <- 2*(precision4*recall4)/(precision4+recall4)
#5
perceptron <- neuralnet(class ~., data=train_data5, hidden=0)
op <- compute(perceptron, test_data5)
prediction<-op$net.result
prediction <- ifelse(prediction > 0.5, 1, 0)
t<-table(test_data5$class,sign(prediction))
acc5 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision5 <- t[2,2]/(t[2,2]+t[2,1])
recall5 <- t[2,2]/(t[2,2]+t[1,2])
F15 <- 2*(precision5*recall5)/(precision5+recall5)

acc_mean <- mean(c(acc1,acc2,acc3,acc4,acc5))
precision_mean <- mean(c(precision1,precision2,precision3,precision4,precision5))
recall_mean <- mean(c(recall1,recall2,recall3,recall4,recall5))
F1_mean <- mean(c(F11,F12,F13,F14,F15))

plot(perceptron)

#INIZIO CLASSIFICAZIONE REGRESSIONE LOGISTICA
#1
reg_l <- glm(class ~., data=train_data1, family="binomial")
op <- predict(reg_l,test_data1,type="response")
op <- ifelse(op > 0.5, 1, 0)
t <- table(test_data1$class,op)
t
acc1 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision1 <- t[2,2]/(t[2,2]+t[2,1])
recall1 <- t[2,2]/(t[2,2]+t[1,2])
F11 <- 2*(precision1*recall1)/(precision1+recall1)
#2
reg_l <- glm(class ~., data=train_data2, family="binomial")
op <- predict(reg_l,test_data2,type="response")
op <- ifelse(op > 0.5, 1, 0)
t <- table(test_data2$class,op)
t
acc2 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision2 <- t[2,2]/(t[2,2]+t[2,1])
recall2 <- t[2,2]/(t[2,2]+t[1,2])
F12 <- 2*(precision2*recall2)/(precision2+recall2)
#3
reg_l <- glm(class ~., data=train_data3, family="binomial")
op <- predict(reg_l,test_data3,type="response")
op <- ifelse(op > 0.5, 1, 0)
t <- table(test_data3$class,op)
t
acc3 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision3 <- t[2,2]/(t[2,2]+t[2,1])
recall3 <- t[2,2]/(t[2,2]+t[1,2])
F13 <- 2*(precision3*recall3)/(precision3+recall3)
#4
reg_l <- glm(class ~., data=train_data4, family="binomial")
op <- predict(reg_l,test_data4,type="response")
op <- ifelse(op > 0.5, 1, 0)
t <- table(test_data4$class,op)
t
acc4 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision4 <- t[2,2]/(t[2,2]+t[2,1])
recall4 <- t[2,2]/(t[2,2]+t[1,2])
F14 <- 2*(precision4*recall4)/(precision4+recall4)
#1
reg_l <- glm(class ~., data=train_data5, family="binomial")
op <- predict(reg_l,test_data5,type="response")
op <- ifelse(op > 0.5, 1, 0)
t <- table(test_data5$class,op)
t
acc5 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision5 <- t[2,2]/(t[2,2]+t[2,1])
recall5 <- t[2,2]/(t[2,2]+t[1,2])
F15 <- 2*(precision5*recall5)/(precision5+recall5)

acc_mean <- mean(c(acc1,acc2,acc3,acc4,acc5))
precision_mean <- mean(c(precision1,precision2,precision3,precision4,precision5))
recall_mean <- mean(c(recall1,recall2,recall3,recall4,recall5))
F1_mean <- mean(c(F11,F12,F13,F14,F15))

#INIZIO CLASSIFICAZIONE ALBERO DECISIONALE
#1
albero <- rpart(class ~ Polyuria+Polydipsia+Gender+Alopecia, data=train_data1, method="class")
#rpart.plot(albero)
prediction <- predict(albero,test_data1,type="class")
t<- table(test_data1$class,prediction)
acc1 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision1 <- t[2,2]/(t[2,2]+t[2,1])
recall1 <- t[2,2]/(t[2,2]+t[1,2])
F11 <- 2*(precision1*recall1)/(precision1+recall1)

#2
albero <- rpart(class ~ Polyuria+Polydipsia+Gender+Alopecia, data=train_data2, method="class")
#rpart.plot(albero)
prediction <- predict(albero,test_data2,type="class")
t<- table(test_data2$class,prediction)
acc2 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision2 <- t[2,2]/(t[2,2]+t[2,1])
recall2 <- t[2,2]/(t[2,2]+t[1,2])
F12 <- 2*(precision2*recall2)/(precision2+recall2)

#3
albero <- rpart(class ~ Polyuria+Polydipsia+Gender+Alopecia, data=train_data3, method="class")
#rpart.plot(albero)
prediction <- predict(albero,test_data3,type="class")
t<- table(test_data3$class,prediction)
acc3 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision3 <- t[2,2]/(t[2,2]+t[2,1])
recall3 <- t[2,2]/(t[2,2]+t[1,2])
F13 <- 2*(precision3*recall3)/(precision3+recall3)

#4
albero <- rpart(class ~ Polyuria+Polydipsia+Gender+Alopecia, data=train_data4, method="class")
rpart.plot(albero)
prediction <- predict(albero,test_data4,type="class")
t<- table(test_data4$class,prediction)
t
acc4 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision4 <- t[2,2]/(t[2,2]+t[2,1])
recall4 <- t[2,2]/(t[2,2]+t[1,2])
F14 <- 2*(precision4*recall4)/(precision4+recall4)

#5
albero <- rpart(class ~ Polyuria+Polydipsia+Gender+Alopecia, data=train_data5, method="class")
#rpart.plot(albero)
prediction <- predict(albero,test_data5,type="class")
t<- table(test_data5$class,prediction)
acc5 <- (t[1,1]+t[2,2])/(t[1,2]+t[2,1]+t[1,1]+t[2,2])
precision5 <- t[2,2]/(t[2,2]+t[2,1])
recall5 <- t[2,2]/(t[2,2]+t[1,2])
F15 <- 2*(precision5*recall5)/(precision5+recall5)

acc_mean <- mean(c(acc1,acc2,acc3,acc4,acc5))
precision_mean <- mean(c(precision1,precision2,precision3,precision4,precision5))
recall_mean <- mean(c(recall1,recall2,recall3,recall4,recall5))
F1_mean <- mean(c(F11,F12,F13,F14,F15))
