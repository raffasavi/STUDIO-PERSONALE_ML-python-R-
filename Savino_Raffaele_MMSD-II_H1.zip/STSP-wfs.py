import csv
from itertools import combinations
import time
from tabulate import tabulate
import gurobipy as gp
from gurobipy import GRB
import networkx as nx


################################### Funzioni ####################################
#################################################################################
def read_Gxss(file_path, sep=','):
    #Lettura
    with open(file_path, 'r') as file:
        csv_r = csv.reader(file, delimiter=sep)
    #Creazione strutture dati
        line = next(csv_r)
        n = int(line[0])
        dist = {(i, j): 0 for i in range(n) for j in range(n)}
        #print(dist)
    #Riempimento strutture dati
        for i in range(n):
            line = next(csv_r)
            for j in range(n):
                dist[i, j] = int(line[j])
        #print(dist)
    return n, dist


def read_SxClassX(file_path, sep=','):
    # Lettura
    with open(file_path, 'r') as file:
        csv_r = csv.reader(file, delimiter=sep)
    # Creazione e riempimento strutture dati
        forb_seq = []
        for row in csv_r:
            if row[-1] == '': row.pop()
            forb_seq.append(row)
        #print(forb_seq)
    return forb_seq


def subtour(edges, n):
    ciclomin = range(n + 2)
    unvisited = list(range(n))
    #esci quanto hai controllato tutti i subtour
    while unvisited:
        this_ciclo = []
        n_vicini = unvisited
        #esci quando il subtour attuale si chiude
        while n_vicini:
            current = n_vicini[0]
            n_vicini = []
            this_ciclo.append(current)
            unvisited.remove(current)
            #ricerca dei vicini del nodo attuale
            for e in edges:
                if e[0] == current and e[1] in unvisited:
                    n_vicini = [e[1]]
                    #print('controllo:',e, e[1], 'è un vicino')
        
        #quando chiudo un subtour controllo se è il più breve
        this_ciclo.append(this_ciclo[0])
        if len(ciclomin) > len(this_ciclo):
            ciclomin = this_ciclo
        #controllati tutti i subtour ritorno il più breve trovato
    return ciclomin

#lettura file
start_time = time.time()
n, dist = read_Gxss(file_path="G1ss.csv")
forb_seq = read_SxClassX(file_path='S1_ClassA.csv')

#creazione grafo
G = nx.Graph()
G2 = nx.path_graph
G.add_node(range(n))
for i in combinations(range(n), 2):
    G.add_edges_from([i])

################################Inizio risoluzione###############################
#################################################################################
print('---------------------------------------------DATI ISTANZA----------------------------------------------')
print(' \t-numVertici:', n, '\n', '\t-matDistanze:', dist, '\n', '\t-seqProibite:', forb_seq)
print('\t-Grafo:', G.edges.data())
print('----------------------------------------cicli subtour-----------------------------------------')

#####################Creazione modello: variabili,vincoli e f.ob#################
m = gp.Model("STSP-wfs")

#variabili sugli archi del grafo
e = m.addVars(G.edges(), vtype=GRB.BINARY, name='e')
for i, j in e.keys():
    e[j, i] = e[i, j]

#vincoli di grado
m.addConstrs(e.sum(i, '*') == 2 for i in range(n))

#Creazione vincoli: forbidden sequence
for seq in forb_seq:
    m.addConstr(sum(e[int(seq[i]), int(seq[i+1])] for i in range(len(seq)-1)) <= len(seq)-2)

#f.ob.
m.setObjective(e.prod(dist)/2, GRB.MINIMIZE)

#Creazione vincoli di subtour
tourLength = 0
iterCount = 1
edges = []

###ricerca degli archi usati
while tourLength < n+1:
    m.optimize() #richiamo risolutore
    for i in range(n):
        for j in range(n):
            if i != j and e[i, j].X > 0.5:
                edges.append([i, j])

    # ricerca del subtour più breve
    tour = subtour(edges, n)
    edges = []
    # eliminazione del subtour trovato
    tourLength = len(tour) #tour è il minTour della funzione di ricerca subtour
    print('***************************************************************************************************')
    print('\t-iterazione=%4d \n\t-length= %4d \n\t-tour= %s ' % (iterCount, tourLength, tour))
    if tourLength < n+1:
        iterCount = iterCount + 1
        # creazione vincolo
        m.addConstr(sum(e[tour[i], tour[i + 1]] for i in range(tourLength - 1)) <= tourLength - 2)
        print('\t####sub-tour eliminato####')
    else: print('\t####tour unico####')
    print('***************************************************************************************************')
    m.write("STSP-wfs.lp")

################################Fine risoluzione#################################
#################################################################################

print('------------------------------------------RISULTATO ISTANZA--------------------------------------------')
if m.status ==  GRB.OPTIMAL:
    print('\t-Solution value = ', m.objval)
    print("\t-Resolution time = %.3f seconds " % float(time.time() - start_time))


controlli = 1
if controlli == 1:
    data = []
    for i in m.getVars():
        if i.X > 0.5:
            data.append([i.varName, i.X])
    print(tabulate(data, headers=['Edges', 'Value']))